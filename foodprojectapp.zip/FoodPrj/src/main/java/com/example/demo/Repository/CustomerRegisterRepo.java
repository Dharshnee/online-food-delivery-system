package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.demo.Model.CustomerRegister;

import java.util.List;

public interface CustomerRegisterRepo extends JpaRepository<CustomerRegister,Integer>{
	//List<CustomerRegister>findAllCustomerByUsername(String�username);
	List<CustomerRegister>findAllCustomerByUsername(String username);

}
